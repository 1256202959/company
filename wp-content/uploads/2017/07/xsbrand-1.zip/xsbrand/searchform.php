<form method="get" id="searchform" action="<?php bloginfo('url'); ?>">
		<input type="text" class="field" name="s" id="s" placeholder="输入搜索内容...">
		<input type="submit" class="submit" name="submit" id="searchsubmit" value="Search">
</form>